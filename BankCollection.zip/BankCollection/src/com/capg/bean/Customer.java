package com.capg.bean;

public class Customer {

	private int AccountNo;
	private String name;
	private String mobile;
	private String address;
	private double balance;
	public int getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Customer(int accountNo, String name, String mobile, String address, double balance) {
		super();
		AccountNo = accountNo;
		this.name = name;
		this.mobile = mobile;
		this.address = address;
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [AccountNo=" + AccountNo + ", name=" + name + ", mobile=" + mobile + ", address=" + address
				+ ", balance=" + balance + "]";
	}
	
	
	
}
