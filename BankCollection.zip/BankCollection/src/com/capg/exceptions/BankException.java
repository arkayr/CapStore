package com.capg.exceptions;

public class BankException extends Exception {
	
	public BankException(String msg)
	{
		super(msg);
	}

}
