package com.capg.service;

import java.util.List;

import com.capg.bean.Customer;
import com.capg.bean.Transaction;

public interface BankServiceIntf {
	
	public int createAccount(Customer customer);
	public double showBalance(int accountNo);
	List<Transaction> deposit(int accountNo, double balance);
	List<Transaction> withdraw(int accountNo, double balance);
	List<Transaction> fundTransfer(int sourceAccountNo, int destinationAccountNo, double balance);
	List<Transaction> printTransaction(int accountNo);
	
	
	
}
