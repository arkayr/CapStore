package com.capg.service;

import java.util.List;

import com.capg.bean.Customer;
import com.capg.bean.Transaction;
import com.capg.dao.BankDAO;

public class BankService implements BankServiceIntf {

	BankDAO bankDao = new BankDAO();
	
	@Override
	public int createAccount(Customer customer) {
		// TODO Auto-generated method stub
		return bankDao.createAccount(customer);
	}

	@Override
	public double showBalance(int accountNo) {
		// TODO Auto-generated method stub
		return bankDao.showBalance(accountNo);
	}

	@Override
	public List<Transaction> deposit(int accountNo, double balance) {
		// TODO Auto-generated method stub
		return bankDao.deposit(accountNo, balance);
	}

	@Override
	public List<Transaction> withdraw(int accountNo, double balance) {
		// TODO Auto-generated method stub
		return bankDao.withdraw(accountNo, balance);
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccountNo, int destinationAccountNo, double balance) {
		// TODO Auto-generated method stub
		return bankDao.fundTransfer(sourceAccountNo, destinationAccountNo, balance);
	}

	@Override
	public List<Transaction> printTransaction(int accountNo) {
		// TODO Auto-generated method stub
		return bankDao.printTransaction(accountNo);
	}
	
	

}
