package com.capg.presentation;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capg.bean.Customer;
import com.capg.bean.Transaction;
import com.capg.service.BankService;

public class MainUI {

	public static void main(String[] args) {
		String continueChoice;
		Scanner scanner = new Scanner(System.in);

		do {
			System.out.println("Welcome to Bank");
			System.out.println("1. Create Bank Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transaction \n");

			System.out.println("Enter your choice: ");
			int choice = scanner.nextInt();

			BankService service = new BankService();

			switch (choice) {
			case 1: // create account

				System.out.println("Enter name: ");
				String name = scanner.next();
				System.out.println("Enter mobile: ");
				String mobile = scanner.next();
				System.out.println("Enter address: ");
				String address = scanner.next();

				Customer customer = new Customer(0, name, mobile, address, 0);
				int accountNo = 0;
				accountNo = service.createAccount(customer);

				System.out.println("Account created successfully with account number: " + accountNo);

				break;

			case 2: // show balance
				
				System.out.println("Enter the account number: ");
				accountNo = scanner.nextInt();
				double balance = 0;
				balance = service.showBalance(accountNo);
				System.out.println("your balance is:" +balance);
				
				break;

			case 3: // deposit
				
				System.out.println("Enter your account number: ");
				accountNo = scanner.nextInt();
				System.out.println("Enter the amount you want to deposit:");
				balance = scanner.nextDouble();
				List<Transaction> transaction = new ArrayList<>();
				transaction = service.deposit(accountNo, balance);
				System.out.println("amount deposited is:" +transaction);
				
				break;

			case 4: // withdraw
				
				System.out.println("Enter the account number: ");
				accountNo = scanner.nextInt();
				System.out.println("Enter the amount you want to withdraw");
				balance = scanner.nextDouble();
				transaction = new ArrayList<>();
				transaction = service.withdraw(accountNo, balance);
				System.out.println(transaction);
				
				break;

			case 5: // fund transfer
				break;

			case 6: // print transaction
				break;

			case 7:
				System.exit(0);

			default:
				System.err.println("Input should be between 1 and 6");
				break;
			}

			System.out.println("Do you want to continue (yes/no)");
			continueChoice = scanner.next();
			if (continueChoice.equals("no")) {
				System.exit(choice);
			}

		} while (true);

	}

}
