package com.capg.dao;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capg.bean.Customer;
import com.capg.bean.Transaction;

public class BankDAO implements BankDAOIntf {

	static Map<Integer, Customer> map = new HashMap<>(); 
	
	@Override
	public int createAccount(Customer customer) {
		// TODO Auto-generated method stub
		int accountNo = (int)(Math.random()*1000);
		customer.setAccountNo(accountNo);
		map.put(accountNo, customer);
		return accountNo;
	}

	@Override
	public double showBalance(int accountNo) {
		// TODO Auto-generated method stub
		double balance = 0;
		boolean status = map.containsKey(accountNo);
		if(status == false)
		{
			/*try {
				throw new Exception("Account number is not in the list");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			System.out.println("Account number is not in the list");
		}
		else
		{
			Customer customer = map.get(accountNo);
			balance = customer.getBalance();
		}
				
		return balance;
	}

	@Override
	public List<Transaction> deposit(int accountNo, double balance) {
		// TODO Auto-generated method stub
		
		int transactionId = (int)(Math.random()*100);
		List<Transaction> transactionList = new ArrayList<>();
		
		Customer customer = map.get(accountNo);
		balance = customer.getBalance() + balance;
		Transaction transaction = new Transaction(accountNo, transactionId,"Deposit",balance);
		transactionList.add(transaction);
		customer.setBalance(balance);
		
		return transactionList;
	}

	@Override
	public List<Transaction> withdraw(int accountNo, double balance) {
		// TODO Auto-generated method stub
		
		int transactionId = (int)(Math.random()*100);
		List<Transaction> transactionList = new ArrayList<>();
		Customer customer = map.get(accountNo);
		balance = customer.getBalance() - balance;
		Transaction transaction = new Transaction(accountNo,transactionId,"Withdraw",balance);
		transactionList.add(transaction);
		return transactionList;
	}

	@Override
	public List<Transaction> fundTransfer(int sourceAccountNo, int destinationAccountNo, double balance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> printTransaction(int accountNo) {
	
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
