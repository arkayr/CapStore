package com.capg.client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capg.entity.BankEntity;
import com.capg.entity.TransactionEntity;
import com.capg.service.BankServiceImpl;

public class Client {

	public static void main(String[] args) {

		// Scanner Object
		Scanner scannerObj = new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		BankServiceImpl bankService = context.getBean("bankService", BankServiceImpl.class);
		String string;
		int choose, balance;
		String choice, name, password, phoneNo;

		while (true) {
			System.out.println("*************Welcome To Your Bank************************");

			System.out.println("Choose 1 to create account");
			System.out.println("Choose 2 to show balance");
			System.out.println("Choose 3 to deposit balance");
			System.out.println("Choose 4 to withdraw money");
			System.out.println("Choose 5 for fund transfer");
			System.out.println("Choose 6 for print transaction");
			System.out.println("Choose 7 for exit");

			System.out.println("*********************************************************");
			System.out.println("Enter Your Choice : ");
			string = scannerObj.next();

			if (string.matches("[a-z]*") || string.matches("[A-Z]*")) {
				System.out.println("Invalid Choice!!!");
				main(null);
			}
			
			
			
			//create account

			switch (string) {
			case "1":

				do {
					System.out.println("Enter Your Name");
					name = scannerObj.next();
					choose = bankService.nameValidate(name);
				} while (choose != 1);

				do {
					System.out.println("Enter Your Contact Number");
					phoneNo = scannerObj.next();
					choose = bankService.mobNoValidate(phoneNo);
				} while (choose != 1);

				long phone1 = Long.parseLong(phoneNo);
				long accountNo = phone1 - 500000;

				do {
					System.out.println("Create Your Pin");
					password = scannerObj.next();
					choose = bankService.passwordValidate(password);
				} while (choose != 1);

				do {
					System.out.println("Enter Deposit Balance");
					balance = scannerObj.nextInt();
					choose = bankService.checkBalance(balance);
				} while (choose != 1);

				boolean result = bankService.createAccount(name, phoneNo, password, accountNo, balance);
				if (result) {
					System.out.println("Account Created Successful: " + accountNo);
				}
				break;
				
			//show balance

			case "2":

				System.out.println("Enter Your Account Number");
				accountNo = scannerObj.nextLong();
				System.out.println("Enter Your Pin");
				password = scannerObj.next();
				boolean b1 = bankService.validateAccount(accountNo, password);
				if (b1) {
					balance = bankService.showBalance(accountNo);
					if (balance != 0) {
						System.out.println("Your Account Balance Is " + balance);
					} else {
						System.out.println("Problem ");
					}
				} else {
					System.out.println(" You Have Entered Wrong Credentials");
				}

				break;
				
				
			//deposit balance
			case "3":
				System.out.println("Enter Your Account Number");
				accountNo = scannerObj.nextLong();
				System.out.println("Enter Your Pin");
				password = scannerObj.next();
				boolean b = bankService.validateAccount(accountNo, password);
				if (b) {
					System.out.println("Enter The Amount You Want To Be Deposited");
					int deposit = scannerObj.nextInt();
					balance = bankService.depositAmount(accountNo, deposit);
					System.out.println("Your New Balance Is " + balance);
				} else {
					System.out.println("You Have Entered Wrong Credentials");
				}
				break;
				
				
			//withdraw
			case "4":

				System.out.println("Enter Your Account Number");
				accountNo = scannerObj.nextLong();
				System.out.println("Enter Your Pin");
				password = scannerObj.next();
				b = bankService.validateAccount(accountNo, password);
				if (b) {
					balance = bankService.showBalance(accountNo);
					System.out.println("Enter The Amount You Want To Be Withdrawal");
					int withdraw = scannerObj.nextInt();
					balance = bankService.withdrawAmount(accountNo, withdraw);
					if (balance >= 0) {
						System.out.println("You Have Withdrawed " + withdraw);
						System.out.println("your new balance is " + balance + "\n");
					} else {
						System.out.println("Insufficient Funds In Your Account");
					}
				}

				else {
					System.out.println("You Have Entered Wrong Credentials");
				}
				break;
				
			//fund transfer

			case "5":

				System.out.println("Enter Your Account Number");
				accountNo = scannerObj.nextLong();
				System.out.println("Enter Your Pin");
				password = scannerObj.next();
				b = bankService.validateAccount(accountNo, password);
				if (b) {
					System.out.println("\nEnter Account Number YOu Want To Transfer");
					long accno = scannerObj.nextLong();
					System.out.println("Enter the Amount You Want To Transfer");
					int amount = scannerObj.nextInt();
					boolean transfer = bankService.fundTransfer(accountNo, accno, amount);
					if (transfer) {
						System.out.println(amount + " is Transferred Successfully\n");
					} else {
						System.out.println("Problem in transfer");
					}
				} else {
					System.out.println("You Have Entered Invalid Account Number");
				}

				break;
				
				
			//print transaction
			case "6":
				System.out.println("Enter Your Account Number");
				accountNo = scannerObj.nextLong();
				System.out.println("Enter Your Pin");
				password = scannerObj.next();
				b = bankService.validateAccount(accountNo, password);
				if (b) {
					List<TransactionEntity> trans = bankService.getTransaction(accountNo);

					System.out.println("----------Transaction Details----------\n");

					for (TransactionEntity tran : trans) {
						System.out.println(tran);
					}

				} else {
					System.out.println("Account not exist!");
				}
				break;
				
			//exit

			case "7":
				System.out.println(" Thanku for visiting");
				System.exit(0);
			}

		}

	}

}
