package com.capg.dao;

import java.util.List;

import com.capg.entity.BankEntity;
import com.capg.entity.TransactionEntity;

public interface IBankDao {
   boolean createAccount(BankEntity bank);
   int showBalance(long accountNo);
   int depositBalance(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean fundTransfer(long accountNo, long accno, int amount);
   boolean validateAccount(long accountNo,String password);
	public List<TransactionEntity> getTransactions(long accountNo) ;
	


}
