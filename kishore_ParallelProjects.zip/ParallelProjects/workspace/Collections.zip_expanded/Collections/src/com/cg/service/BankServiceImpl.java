package com.cg.service;

import com.cg.bean.Bank;
import com.cg.dao.BankDaoImpl;
import com.cg.dao.IBankDao;
import com.cg.exceptions.AccountAlreadyExistsException;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.LowBalanceException;


public class BankServiceImpl implements IBankService {

	IBankDao bankDaoObj = new BankDaoImpl();
	Bank bank = new Bank();
	Bank bank1 = new Bank();

	boolean result;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String add, long accNo, String phone, int pin, int bal)
			throws AccountAlreadyExistsException {

		Bank bean = new Bank();
		boolean result = false;

		if (bankDaoObj.checkAccount(accNo) == null) {

			bean.setAccNo(accNo);
			bean.setAddress(add);
			bean.setBalance(bal);
			bean.setName(name);
			bean.setPhoneNo(phone);
			bean.setPin(pin);
			bean.setTrans("Account Created with Balance  : " + bal + "\n");

			bankDaoObj.setData(accNo, bean);

			result = true;
		}

		else

		{
			result = false;
			throw new AccountAlreadyExistsException();
		}
		return result;

	}

	// to show balance

	public int showBalance(long accNo) throws AccountNotFoundException {

		bank = bankDaoObj.checkAccount(accNo);
		int balance = 0;
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			balance = bank.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long accNo, int deposit_amount) throws AccountNotFoundException {

		int balance = 0;
		bank = bankDaoObj.checkAccount(accNo);

		if (bank == null) {
			throw new AccountNotFoundException();
		} else {

			balance = bank.setBalance(bank.getBalance() + deposit_amount);
			String s = bank.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			bank.setTrans(s);
			bankDaoObj.setData(accNo, bank);
		}

		return balance;
	}

	// to withdraw

	public int withdraw(long accNo, int withdraw_amount) throws AccountNotFoundException, LowBalanceException {

		int balance = 0;
		bank = bankDaoObj.checkAccount(accNo);
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			if (bank.getBalance() > withdraw_amount) {
				balance = bank.setBalance(bank.getBalance() - withdraw_amount);
				String s = bank.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				bank.setTrans(s);
			} else {
				throw new LowBalanceException();
			}
			bankDaoObj.setData(accNo, bank);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException {

		bank =bankDaoObj.checkAccount(accNo);

		if (!(bank == null)) {

			bank1 = bankDaoObj.checkAccount(accNo1);

			if (!(bank1 == null))

			{

				int sender_balance = bank.getBalance();

				if (sender_balance > transfer_amount) {
					int reciever_balance = bank1.getBalance();

					bank.setBalance(sender_balance - transfer_amount);
					bank1.setBalance(reciever_balance + transfer_amount);
					String s = bank.getTrans() + "Transferred to  :" + accNo1 + " Amount : " + transfer_amount + "\n";
					bank.setTrans(s);
					String s1 = bank1.getTrans() + "Transferred from  :" + accNo + " Amount : " + transfer_amount
							+ "\n";
					bank1.setTrans(s1);
					bankDaoObj.setData(accNo, bank);
					bankDaoObj.setData(accNo1, bank1);
				} else {
					throw new LowBalanceException();
				}
			}

			else {
				throw new AccountNotFoundException();
			}
		} else {
			throw new AccountNotFoundException();
		}

		return true;
	}

	// to validateBalance

	public boolean validateBalance(long accNo, int amount) throws LowBalanceException

	{
		bank = bankDaoObj.checkAccount(accNo);
		if (bank == null) {
			throw new LowBalanceException();
		} else {
			return true;
		}
	}

	// to set transactions

	public String setTrans(long accNo) throws AccountNotFoundException {

		bank = bankDaoObj.checkAccount(accNo);
		String s;

		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			s = bank.getTrans();
		}
		return s;
	}

}
