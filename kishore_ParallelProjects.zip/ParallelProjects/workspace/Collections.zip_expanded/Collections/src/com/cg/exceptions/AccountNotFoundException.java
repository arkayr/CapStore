package com.cg.exceptions;

public class AccountNotFoundException extends Exception {

	public AccountNotFoundException() {

	}

	public String toString() {

		return "Account Number Not Found . \nPlease Enter a valid Account Number!!!";
	}

}
