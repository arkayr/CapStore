package com.cg.exceptions;

public class LowBalanceException extends Exception {

	public LowBalanceException() {

	}

	@Override
	public String toString() {
		return "Account Balance Is Low  \nCannot Perform This Operation";
	}

}
