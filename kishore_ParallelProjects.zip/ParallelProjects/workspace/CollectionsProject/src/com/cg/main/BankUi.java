package com.cg.main;

import java.util.Scanner;

import com.cg.exceptions.AccountAlreadyExistsException;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.LowBalanceException;
import com.cg.service.BankServiceImpl;
import com.cg.service.IBankService;

public class BankUi {

	public static void main(String args[]) {
		Scanner scannerObj = new Scanner(System.in);     //Scanner object

		long accountNo, accountNo1;
		int withdraw_amount, deposit_amount = 0, transfer_amount = 0;
		int pin;
		int amount = 0;
		int balance = 0;
		boolean result = false;

		IBankService serviceObj = new BankServiceImpl();

		/**
		 * Menu For User
		 */

		while (true) {
			System.out.println("------------Welcome To Your Bank----------");
			System.out.println("choose 1 to Create Account");
			System.out.println("choose 2 to Show Balance");
			System.out.println("choose 3 to Deposit");
			System.out.println("choose 4 to Withdraw");
			System.out.println("choose 5 to Transer Fund");
			System.out.println("choose 6 to Print Transcations");
			System.out.println("choose 7 to Exit");

			int choice = scannerObj.nextInt();
			scannerObj.nextLine();
			
			
			switch (choice) {

			/**
			 * This case is for to create account
			 */

			case 1:
				System.out.println("Enter Your Name");
				String name = scannerObj.nextLine();
				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Invalid Format");
					System.out.println("Enter Your Name");
					name = scannerObj.next();
				}

				System.out.println("Enter Your Address ");
				String address = scannerObj.nextLine();

				while (!address.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.println("Enter Your Address ");
					address = scannerObj.nextLine();

				}

				System.out.println("Enter Contact Number");
				String phone = scannerObj.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Contact number should be 0f 10 digits");
						System.out.println("Enter Your Contact Number");
						phone = scannerObj.next();
					}
					System.out.println("Contact number should start from 6-9");
					System.out.println("Enter Your Contact number");
					phone = scannerObj.next();
				}

				accountNo = Long.parseLong(phone) % 100000;

				System.out.println("Enter Pin Number");
				pin = scannerObj.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin number should be 0f 4 digits");
					System.out.println("Enter Pin Number");
					pin = scannerObj.nextInt();
				}

				System.out.println("Enter Balance To Your Account ");
				int bal = scannerObj.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter Balance To Your Account");
					bal = scannerObj.nextInt();

				}
				try {
					result = serviceObj.createAccount(name, address, accountNo, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (result == true) {
					System.out.println("Account Created Successfully With Account Number : " + accountNo + "  !!!");

				} else {

					System.out.println("Cannot Create Account");

				}

				break;

			/**
			 * This case is to show balance
			 */
			case 2:

				System.out.println("Enter your Account Number");
				accountNo = scannerObj.nextLong();

				try {
					balance = serviceObj.showBalance(accountNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Current Balance :" + balance);

				break;

			/**
			 * This case is to deposit amount
			 */
			case 3:

				System.out.println("Enter Your Account Number");
				accountNo = scannerObj.nextLong();

				System.out.println("Enter Amount to be deposited");
				deposit_amount = scannerObj.nextInt();

				try {
					amount = serviceObj.deposit(accountNo, deposit_amount);

					balance = serviceObj.showBalance(accountNo);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited : " + deposit_amount);
				System.out.println("Current Balance : " + balance);

				break;

			/**
			 * This case is to withdraw amount
			 */

			case 4:

				System.out.println("Enter Account number");
				accountNo = scannerObj.nextLong();

				System.out.println("Enter Amount You Want To Withdraw");
				withdraw_amount = scannerObj.nextInt();

				try {
					amount = serviceObj.withdraw(accountNo, withdraw_amount);
					result = serviceObj.validateBalance(accountNo, withdraw_amount);
					balance = serviceObj.showBalance(accountNo);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdraw_amount);
				System.out.println("Current Balance : " + balance);

				break;

			/**
			 * This case is to fund transfer
			 */

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter Your Account Number");
				accountNo = scannerObj.nextLong();

				System.out.println("Enter Account Number To which You Want To Transfer Fund");
				accountNo1 = scannerObj.nextLong();

				System.out.println("Enter Amount To Transfer");
				transfer_amount = scannerObj.nextInt();

				try {
					result = serviceObj.validateBalance(accountNo, transfer_amount);
					result = serviceObj.transferfund(accountNo, accountNo1, transfer_amount);

					senders_balance = serviceObj.showBalance(accountNo);
					recievers_balance = serviceObj.showBalance(accountNo1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully");
				System.out.println("Current Balance for Your  Account " + accountNo + " : " + senders_balance);

				break;

			/**
			 * This case is to print transaction
			 */

			case 6:

				String s = null;
				System.out.println("Enter  Your Account Number");
				accountNo = scannerObj.nextLong();
				System.out.println("Enter  Your Pin Number");
				pin = scannerObj.nextInt();
				try {
					s = serviceObj.setTrans(accountNo);
					System.out.println(s);
				} catch (AccountNotFoundException e) {
					System.out.println(e);

				}
				break;

			/**
			 * This case is to exit by user
			 */

			case 7:
				System.out.println("Thank you for using your service ");
				System.exit(0);
				break;

			default:
				System.out.println("Please Enter Choice Between 1 - 7 ");

			}
		}

	}

}
