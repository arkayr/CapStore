package com.cg.dao;

import java.sql.SQLException;

import com.cg.bean.Bank;
import com.cg.bean.BankTransaction;



public interface IBankDao {



	public void InsertData(long accNo, Bank bean) throws ClassNotFoundException, SQLException;
	
	public void updateData(Bank bean) throws ClassNotFoundException, SQLException;

	public boolean checkAccount(long accNo) throws ClassNotFoundException, SQLException;

	public Bank getAccountDetails(long accNo) throws ClassNotFoundException, SQLException;

	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException;

	public BankTransaction getTransactions(long accNo) throws ClassNotFoundException, SQLException;

}
