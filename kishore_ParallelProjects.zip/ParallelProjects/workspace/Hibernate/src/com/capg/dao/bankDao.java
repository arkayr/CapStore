package com.capg.dao;

import com.capg.entity.bankEntity;

public interface bankDao {
	public   bankEntity getAccountById(int id);

	public   void CreateAccount(bankEntity bank);

	public   void ShowBalance(bankEntity bank);

	public  void Deposit(bankEntity bank);
	
	public void Withdraw(bankEntity bank);
	
	public void PrintTransactions(int id);

	public  void commitTransaction();

	public void beginTransaction();

}
