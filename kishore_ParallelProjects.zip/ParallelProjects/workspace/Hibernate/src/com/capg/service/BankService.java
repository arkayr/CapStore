package com.capg.service;

import com.capg.dao.bankDaoImpl;
import com.capg.entity.bankEntity;
import com.capg.entity.transactionEntity;

public class BankService implements BankServiceInterface {
 bankDaoImpl dao=new bankDaoImpl();
 
	@Override
	
	public bankEntity getAccountById(int id) {
	bankEntity bank  = dao.getAccountById(id) ;
		return bank;
	}

	@Override
	public void CreateAccount(bankEntity bank) {
		dao.beginTransaction();
		dao.CreateAccount(bank);
		dao.commitTransaction();
	}

	@Override
	public void ShowBalance(bankEntity bank) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Deposit(bankEntity bank) {
		dao.beginTransaction();
		dao.Deposit(bank);	
		dao.commitTransaction();
 
	}

	@Override
	public void Withdraw(bankEntity bank) {
		dao.beginTransaction();
		dao.Withdraw(bank);
		dao.commitTransaction();
	}

	@Override
	public void PrintTransactions(int id) {
		 dao.PrintTransactions(id);
		
	}

	@Override
	public void commitTransaction() {
	dao.commitTransaction();
		
	}

	@Override
	public void beginTransaction() {
		dao.beginTransaction();
	}

	public void addTransaction(transactionEntity trans) {

	dao.beginTransaction();
	dao.addTransaction(trans);
	dao.commitTransaction();
	}
	 
}

