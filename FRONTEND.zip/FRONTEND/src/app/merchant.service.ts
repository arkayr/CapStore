import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Merchant } from './merchant';
import { AuthService } from './auth.service';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class MerchantService {

  constructor(private http:HttpClient,private authService:AuthService) { }

  getMerchantDetails():Observable<Merchant>{
    return this.http.get<Merchant>("http://localhost:5000/getmerchant/"+this.authService.getMerchantId())
  }

  getProducts():Observable<Product[]>{
    return this.http.get<Product[]>("http://localhost:5000/getProducts/"+this.authService.getMerchantId())
  }

  addProduct(catId:number,product:any):Observable<any>{
    return this.http.post<any>("http://localhost:5000/addProduct/"+this.authService.getMerchantId()+"/"+catId,product);
  }

  uploadImage(formData,productId){
    this.http.post('http://localhost:5000/uploadFile/'+productId, formData).subscribe(data=>{
      console.log(data);
    })
  }

  deleteProduct(productId:number):Observable<any>{
    return this.http.delete("http://localhost:5000/products/delete/"+productId+"/"+this.authService.getMerchantId())
  }

  getInventory():Observable<any[]>{
    return this.http.get<any[]>("http://localhost:5000/inventory/"+this.authService.getMerchantId())
  }
}
