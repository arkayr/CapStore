import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule,   routingComponents} from './app-routing.module';
import { AppComponent } from './app.component';
import { Routes } from '../../node_modules/@angular/router';
import { HomeComponent } from './merchant/home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { MerchantComponent } from './merchant/merchant.component';
import { AddproductComponent } from './merchant/addproduct/addproduct.component';
import { FormsModule } from '@angular/forms';
import { UploadImagesComponent } from './merchant/upload-images/upload-images.component';
import { UpdateInventoryComponent } from './merchant/update-inventory/update-inventory.component';



@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    HomeComponent,
    MerchantComponent,
    AddproductComponent,
    UploadImagesComponent,
    UpdateInventoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
