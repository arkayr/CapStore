import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-inventory',
  templateUrl: './update-inventory.component.html',
  styleUrls: ['./update-inventory.component.css']
})
export class UpdateInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
