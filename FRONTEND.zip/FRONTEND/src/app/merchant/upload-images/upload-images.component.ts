import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../../merchant.service';
import { ActivatedRoute } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-upload-images',
  templateUrl: './upload-images.component.html',
  styleUrls: ['./upload-images.component.css']
})
export class UploadImagesComponent implements OnInit {

  fileData: File = null;
  constructor(private merchantService: MerchantService, private route: ActivatedRoute) { }
  productId: number;
  ngOnInit() {
    this.route.params.subscribe(
      params => this.productId = params.id);
  }

  onFileSelected(event) {
    if (event.target.files.length > 0) {
      //console.log(event.target.files[0].name);
      this.fileData = event.target.files[0];
      console.log(this.fileData.name);
    }
  }

  onSubmit() {
    const formData = new FormData();
    formData.append('file', this.fileData);
    this.merchantService.uploadImage(formData, this.productId);

  }
}
