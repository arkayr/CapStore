import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-inventory',
  templateUrl: './my-inventory.component.html',
  styleUrls: ['./my-inventory.component.css']
})
export class MyInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
