import { Component, OnInit } from '@angular/core';
import { Product } from '../../product';
import { MerchantService } from '../../merchant.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  public descriptions: any[] = [{
    label: '',
    value: ''
  }];


  constructor(private merchantService: MerchantService) { }

  ngOnInit() {
  }

  addDesc() {
    this.descriptions.push({
      label: '',
      value: ''
    });
  }
  remove(i) {
    this.descriptions.splice(i, 1);
  }

  addProduct(data) {
    console.log(data);
    let obj: any = {
      productName: data.productName,
      price: data.Price,
      productDesc: this.descriptions
    }
    console.log(obj);
    this.merchantService.addProduct(data.Category, obj).subscribe(res => {
      alert("added");
    })
  }
}
