package banking.exception;

public class InvalidAccountException extends Exception {

	public InvalidAccountException(String s) {
		super(s);
	}

}
