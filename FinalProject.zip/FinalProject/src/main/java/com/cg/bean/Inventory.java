package com.cg.bean;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Inventory {
	@Id
	@SequenceGenerator(name = "inven_id", sequenceName = "inven_id", initialValue = 200000, allocationSize = 1)
	@GeneratedValue(generator = "inven_id")
	private int inventory_Id;
	@OneToOne
	private Product product;
	private int merchant_id;
	private int stock;
	private Timestamp lastUpdated;
	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Inventory(int inventory_Id, Product product, int merchant_id, int stock, Timestamp lastUpdated) {
		super();
		this.inventory_Id = inventory_Id;
		this.product = product;
		this.merchant_id = merchant_id;
		this.stock = stock;
		this.lastUpdated = lastUpdated;
	}
	public Inventory( Product product, int merchant_id, int stock, Timestamp lastUpdated) {
		super();
		this.product = product;
		this.merchant_id = merchant_id;
		this.stock = stock;
		this.lastUpdated = lastUpdated;
	}
	public int getInventory_Id() {
		return inventory_Id;
	}
	public void setInventory_Id(int inventory_Id) {
		this.inventory_Id = inventory_Id;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getMerchant_id() {
		return merchant_id;
	}
	public void setMerchant_id(int merchant_id) {
		this.merchant_id = merchant_id;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public Timestamp getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Timestamp lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	@Override
	public String toString() {
		return "Inventory [inventory_Id=" + inventory_Id + ", product=" + product + ", merchant_id=" + merchant_id
				+ ", stock=" + stock + ", lastUpdated=" + lastUpdated + "]";
	}
	
	 
	
	
	
}
