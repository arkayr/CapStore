package com.bank.dao;

import java.util.List;

import com.bank.user.bean.TransactionBean;
import com.bank.user.bean.UserBean;

public interface DaoInterface {
	
	int userAccountCreation(UserBean userbean);

	int Login(int accountId, String accountPassword);

	String displayBalance(int accountId);

	String Deposit(int accountId, int amount);

	String withDraw(int accountId, int amount);

	String fundTransfer(int sourceAccountId, int destinationAccountId, int amount);

	List<TransactionBean> printTransactions(int accountId);

	
	boolean validAccountId(int accountId);

	boolean checkBalance(int accountId, int amount);

}
