package com.bank._SpringBoot_ParallelProject.exceptions;

public class GlobalException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GlobalException(String msg) {
		super(msg);
	}

	public GlobalException() {
	}

}
