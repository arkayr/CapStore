export class userModel{
    accountId:number;
    accountPassword:String;
    name:String;
    mobilenumber:number;
    balance:number;

    constructor(accountId:number,accountPassword:string,accountUsername:String,mobilenumber:number,balance:number){
        this.accountId = accountId;
        this.accountPassword = accountPassword;
        this.name = accountUsername;
        this.balance=balance;
        
    }

}